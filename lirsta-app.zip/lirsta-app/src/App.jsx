import React, { useState, useEffect, useRef } from 'react';
import { Menu, X, ArrowRight, Check, Briefcase, Users, RefreshCw, BarChart3, Database, Cpu, HardDrive, Zap, Code, Cloud, CheckCheck } from 'lucide-react';
// Asegúrate de que el archivo App.css esté enlazado en el entorno de ejecución.

/* ----------------------------------------------------------------
   COMPONENTES MODULARES
   ---------------------------------------------------------------- */

const navItems = [
  { name: 'Inicio', href: '#inicio' },
  { name: 'Funcionalidades', href: '#caracteristicas' },
  { name: 'Planes', href: '#planes' },
  { name: 'Calidad', href: '#calidad' },
  { name: 'Contacto', href: '#contacto' },
];

const Navbar = ({ isMenuOpen, toggleMenu }) => (
  <header id="header" className="navbar">
    <a href="#main-content" className="skip-link">Saltar al Contenido</a>
    <div className="container navbar-content">
      <a href="#inicio" className="navbar-logo" aria-label="Lirsta inicio">
        <Database className="w-6 h-6 mr-2 text-primary" />
        Lirsta
      </a>

      <nav className="navbar-nav" aria-label="Navegación Principal">
        {navItems.map((item) => (
          <a
            key={item.name}
            href={item.href}
            className="navbar-link"
          >
            {item.name}
          </a>
        ))}
      </nav>

      <a
        href="#contacto"
        className="btn btn-primary navbar-btn-desktop"
        style={{ display: 'none' }} // Se muestra con CSS media query
      >
        Prueba Gratis
      </a>

      <button
        className="menu-toggle"
        onClick={toggleMenu}
        aria-label={isMenuOpen ? 'Cerrar menú' : 'Abrir menú'}
        aria-expanded={isMenuOpen}
        aria-controls="mobile-menu-list"
      >
        {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
      </button>
    </div>

    {/* Menú Móvil */}
    {isMenuOpen && (
      <div id="mobile-menu-list" className="mobile-menu" aria-label="Menú de Navegación Móvil">
        <div className="container">
          {navItems.map((item) => (
            <a
              key={item.name}
              href={item.href}
              onClick={toggleMenu}
            >
              {item.name}
            </a>
          ))}
          <a
            href="#contacto"
            className="btn btn-primary"
            onClick={toggleMenu}
            style={{ marginTop: '0.5rem' }}
          >
            Prueba Gratis
          </a>
        </div>
      </div>
    )}
  </header>
);

const Hero = () => (
  <section id="inicio" className="section hero animate-on-scroll" role="region" aria-label="Sección Principal de Bienvenida">
    <div className="container text-center">
      <h1 className="hero-title">
        Lirsta: Tu Inventario, <span className="text-primary">Sincronizado</span> y Sin Complicaciones.
      </h1>
      <p className="hero-subtitle">
        La forma más sencilla de crear, gestionar y compartir bases de datos e inventarios en tiempo real, desde cualquier plataforma.
      </p>
      <div className="hero-actions">
        <a
          href="#contacto"
          className="btn btn-primary"
        >
          Comienza tu Prueba Gratuita
          <ArrowRight className="w-5 h-5 ml-2" />
        </a>
        <a
          href="#planes"
          className="btn btn-secondary"
        >
          Ver Planes y Precios
        </a>
      </div>
    </div>
  </section>
);

const Steps = () => (
  <section id="como-funciona" className="section bg-white animate-on-scroll" role="region" aria-label="Pasos de Funcionamiento">
    <div className="container">
      <div className="text-center">
        <h2 className="text-3xl font-weight-extrabold" style={{ fontSize: '2rem' }}>
          Así de Fácil es Gestionar con Lirsta
        </h2>
        <p className="hero-subtitle" style={{ marginTop: 'var(--space-md)' }}>
          Solo 3 pasos para tener tu inventario bajo control.
        </p>
      </div>

      <div className="card-grid card-grid-md-3">
        {/* Paso 1 */}
        <div className="card step-card animate-on-scroll">
          <div className="step-number-wrapper">1</div>
          <h3 className="text-xl font-weight-bold">Crea tu Tabla</h3>
          <p className="mt-2 text-gray-medium text-sm">Define las columnas (Nombre, Stock, Precio, etc.) que necesita tu inventario o base de datos.</p>
        </div>

        {/* Paso 2 */}
        <div className="card step-card animate-on-scroll" style={{ transitionDelay: '0.1s' }}>
          <div className="step-number-wrapper">2</div>
          <h3 className="text-xl font-weight-bold">Añade Registros y Colabora</h3>
          <p className="mt-2 text-gray-medium text-sm">Ingresa los datos. Invita a tu equipo y todos podrán ver y actualizar la información en tiempo real.</p>
        </div>

        {/* Paso 3 */}
        <div className="card step-card animate-on-scroll" style={{ transitionDelay: '0.2s' }}>
          <div className="step-number-wrapper">3</div>
          <h3 className="text-xl font-weight-bold">Accede y Exporta</h3>
          <p className="mt-2 text-gray-medium text-sm">Consulta el inventario desde tu móvil o PC. Genera reportes con un solo clic y mantén el control.</p>
        </div>
      </div>
    </div>
  </section>
);

const PlanCard = ({ name, price, description, features, isPro = false, isSelected, onSelect }) => (
  <div 
    className={`card pricing-card ${isPro ? 'pricing-card-pro' : ''} ${isSelected ? 'selected' : ''}`} 
    role="radio"
    aria-checked={isSelected}
    tabIndex="0"
    onClick={(e) => { 
        e.preventDefault();
        e.stopPropagation();
        onSelect(name);
    }}
    onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            onSelect(name);
        }
    }}
  >
    {isPro && <span className="badge-active">MÁS POPULAR</span>}
    {isSelected && <span className="badge-active" style={{ top: isPro ? '20px' : '-10px', right: isPro ? '-10px' : '-10px', backgroundColor: isPro ? 'var(--color-primary-dark)' : 'var(--color-primary)' }}>SELECCIONADO</span>}
    
    <div className="flex-grow">
      <h3 className={`text-2xl font-weight-bold ${isPro ? 'text-primary' : 'text-gray-dark'}`}>
        {name}
      </h3>
      <p className="pricing-description">
          {description}
      </p>

      <div style={{ marginTop: '1rem' }}>
        <span className="pricing-price">
          {price}
        </span>
        <span style={{ fontSize: '1.25rem', color: 'var(--color-gray-medium)', fontWeight: 500 }}>
          {name !== 'Gratis' && '/mes'}
        </span>
      </div>

      <ul className="pricing-list">
        {features.map((feature, index) => (
          <li key={index}>
            <Check className="w-5 h-5 text-primary" />
            <span>{feature}</span>
          </li>
        ))}
      </ul>
    </div>

    <button
      className={`btn mt-8 w-full ${isSelected ? 'btn-selected' : (name === 'Gratis' ? 'btn-secondary' : 'btn-primary')}`}
      aria-label={isSelected ? `Plan ${name} activo` : `Seleccionar plan ${name}`}
      onClick={(e) => {
          e.stopPropagation(); // Evita doble-trigger con el onClick del div
          onSelect(name);
      }}
      disabled={isSelected} // Deshabilitar el botón si ya está seleccionado
    >
      {isSelected ? (
        <>
          <Check className="w-5 h-5 mr-2" />
          Plan Activo
        </>
      ) : (
        <>
          {name === 'Gratis' ? 'Empezar Gratis' : 'Elegir Plan'}
          <ArrowRight className="w-5 h-5 ml-2" />
        </>
      )}
    </button>
  </div>
);

const Pricing = () => {
  const [selectedPlan, setSelectedPlan] = useState('Pro');

  const plans = [
    {
      name: 'Gratis',
      price: '€0',
      description: 'Perfecto para empezar y probar.',
      features: ['5 Tablas de Inventario', 'Hasta 500 Registros por Tabla', 'Acceso desde 1 Dispositivo', 'Exportación CSV', 'Soporte Estándar (Email)'],
      isPro: false,
    },
    {
      name: 'Pro',
      price: '€15',
      description: 'Ideal para profesionales y pequeños equipos.',
      features: ['Tablas Ilimitadas', 'Registros Ilimitados', 'Sincronización Multiplataforma (PC/Móvil)', 'Colaboración (Hasta 5 usuarios)', 'Reportes Avanzados', 'Soporte Rápido'],
      isPro: true,
    },
    {
      name: 'Empresa',
      price: 'Contáctanos',
      description: 'Para negocios que necesitan escalabilidad.',
      features: ['Tablas y Registros Ilimitados', 'Usuarios Ilimitados', 'Sincronización Multiplataforma', 'Integraciones API Personalizadas', 'Soporte Prioritario 24/7', 'Gestor de Cuenta Dedicado'],
      isPro: false,
    },
  ];

  return (
    <section id="planes" className="section bg-gray-light animate-on-scroll" role="radiogroup" aria-label="Opciones de Planes y Precios">
      <div className="container">
        <div className="text-center">
          <h2 className="text-3xl font-weight-extrabold" style={{ fontSize: '2rem' }}>
            Elige el Plan Perfecto para tu Gestión
          </h2>
          <p className="hero-subtitle" style={{ marginTop: 'var(--space-md)' }}>
            Precios transparentes, sin costes ocultos.
          </p>
        </div>

        {/* CLASE DE ANIMACIÓN APLICADA AL CONTENEDOR GRID */}
        <div className="card-grid card-grid-md-3 animate-on-scroll" style={{ transitionDelay: '0.1s' }}> 
          {plans.map((plan) => (
            <PlanCard 
              key={plan.name} 
              {...plan} 
              isSelected={selectedPlan === plan.name}
              onSelect={setSelectedPlan}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

const Features = () => {
  const featuresList = [
    {
      icon: <RefreshCw className="w-6 h-6" />,
      title: 'Sincronización Multiplataforma',
      description: 'Accede y actualiza tus inventarios desde cualquier dispositivo: móvil, tablet o escritorio. Todos los cambios en tiempo real.',
    },
    {
      icon: <BarChart3 className="w-6 h-6" />,
      title: 'Reportes y Analíticas',
      description: 'Visualiza el estado de tu stock con gráficos intuitivos. Identifica tendencias y puntos de mejora fácilmente.',
    },
    {
      icon: <Database className="w-6 h-6" />,
      title: 'Bases de Datos Robustas',
      description: 'Gestiona miles de registros sin problemas de rendimiento. Diseñado para escalabilidad desde el inicio.',
    },
    {
      icon: <Users className="w-6 h-6" />,
      title: 'Colaboración en Equipo',
      description: 'Invita a tu equipo y define roles de acceso. Trabajen juntos en el mismo inventario de forma segura.',
    },
  ];

  return (
    <section id="caracteristicas" className="section bg-white animate-on-scroll" role="region" aria-label="Características Destacadas de la Aplicación">
      <div className="container">
        <div className="text-center">
          <h2 className="text-3xl font-weight-extrabold" style={{ fontSize: '2rem' }}>
            Funcionalidades que Impulsan tu Negocio
          </h2>
          <p className="hero-subtitle" style={{ marginTop: 'var(--space-md)' }}>
            Herramientas poderosas para gestionar el caos del inventario.
          </p>
        </div>

        <div className="card-grid card-grid-md-2 card-grid-lg-4 animate-on-scroll" style={{ transitionDelay: '0.1s' }}>
          {featuresList.map((feature, index) => (
            <div key={index} className="feature-card" style={{ transitionDelay: `${index * 0.1}s` }}>
              <div className="feature-icon-wrapper" aria-hidden="true">
                {feature.icon}
              </div>
              <h3 className="feature-card h3">{feature.title}</h3>
              <p className="mt-2 text-sm text-gray-medium">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Checklist = () => {
    const qualityItems = [
        { icon: <CheckCheck className="w-6 h-6 text-primary" />, title: 'WCAG AA Compliance', description: 'Revisión manual y automática de accesibilidad (contraste, foco, roles ARIA).' },
        { icon: <Cpu className="w-6 h-6 text-primary" />, title: 'Performance Metrics', description: 'Pruebas Lighthouse (CLS, FCP, LCP) con métricas > 90/100.' },
        { icon: <HardDrive className="w-6 h-6 text-primary" />, title: 'Data Backup Strategy', description: 'Implementación de backups diarios y semanales de la base de datos.' },
        { icon: <Code className="w-6 h-6 text-primary" />, title: 'Code Review & Linting', description: 'Uso de ESLint y Prettier para mantener un código limpio y consistente.' },
    ];
    return (
        <section id="calidad" className="section bg-gray-light animate-on-scroll" role="region" aria-label="Checklist de Calidad para Producción">
            <div className="container" style={{ maxWidth: '896px' }}>
                <div className="text-center">
                    <h2 className="text-3xl font-weight-extrabold" style={{ fontSize: '2rem' }}>
                        Checklist de Calidad (Listo para Prod)
                    </h2>
                    <p className="hero-subtitle" style={{ marginTop: 'var(--space-md)' }}>
                        Nuestra garantía de que el código está preparado para el mundo real.
                    </p>
                </div>
                
                <div style={{ marginTop: '4rem', padding: '2rem', backgroundColor: 'var(--color-white)', borderRadius: '0.75rem', boxShadow: '0 4px 6px rgba(0,0,0,0.1)' }}>
                    <ul className="list-style-none">
                        {qualityItems.map((item, index) => (
                            <li key={index}>
                                {item.icon}
                                <div>
                                    <h3 className="font-weight-bold" style={{ fontSize: '1.125rem', color: 'var(--color-gray-dark)' }}>{item.title}</h3>
                                    <p className="text-sm" style={{ color: 'var(--color-gray-medium)' }}>{item.description}</p>
                                </div>
                            </li>
                        ))}
                    </ul>
                </div>
            </div>
        </section>
    );
}

const DeploymentGuide = () => {
    const steps = [
        { title: 'Prepara el Código', description: 'Asegúrate de que la build de React esté limpia y que todas las dependencias estén instaladas.' },
        { title: 'Elige el Proveedor', description: 'Plataformas recomendadas: Cloudflare Pages (CDN global) o Vercel (integración con Next.js/React).' },
        { title: 'Conecta el Repositorio', description: 'Vincula tu repositorio de Git (GitHub/GitLab) al proveedor de despliegue.' },
        { title: 'Configura la Build', description: 'Comando de Build: `npm run build`. Directorio de Salida: `build` o `dist`.' },
        { title: 'Despliegue Automático', description: 'Cada push a la rama principal (main) disparará un nuevo despliegue automático.' },
    ];
    return (
        <section id="despliegue" className="section bg-white animate-on-scroll" role="region" aria-label="Guía Rápida de Despliegue">
            <div className="container" style={{ maxWidth: '896px' }}>
                <div className="text-center">
                    <h2 className="text-3xl font-weight-extrabold" style={{ fontSize: '2rem' }}>
                        Guía Rápida de Despliegue
                    </h2>
                    <p className="hero-subtitle" style={{ marginTop: 'var(--space-md)' }}>
                        Sube Lirsta a la nube en 5 sencillos pasos.
                    </p>
                </div>
                
                <div style={{ marginTop: '4rem', padding: '2rem', backgroundColor: 'var(--color-gray-light)', borderRadius: '0.75rem', boxShadow: '0 4px 6px rgba(0,0,0,0.1)' }}>
                    <ol className="list-style-none" style={{ counterReset: 'step-counter' }}>
                        {steps.map((step, index) => (
                            <li key={index} style={{ alignItems: 'flex-start', paddingLeft: '2rem', position: 'relative' }}>
                                <div style={{ 
                                    position: 'absolute', 
                                    left: 0, 
                                    top: '0.5rem',
                                    width: '1.5rem', 
                                    height: '1.5rem', 
                                    backgroundColor: 'var(--color-primary)', 
                                    borderRadius: '50%',
                                    display: 'flex', 
                                    justifyContent: 'center', 
                                    alignItems: 'center',
                                    color: 'var(--color-white)',
                                    fontWeight: 'var(--font-weight-bold)',
                                    fontSize: '0.875rem'
                                }}>
                                    {index + 1}
                                </div>
                                <div>
                                    <h3 className="font-weight-bold" style={{ fontSize: '1.125rem', color: 'var(--color-gray-dark)' }}>{step.title}</h3>
                                    <p className="text-sm" style={{ color: 'var(--color-gray-medium)' }}>{step.description}</p>
                                </div>
                            </li>
                        ))}
                    </ol>
                </div>
            </div>
        </section>
    );
}

const FAQ = () => {
  const faqItems = [
    {
      question: '¿Qué diferencia a Lirsta de una hoja de cálculo?',
      answer: 'Lirsta está diseñado específicamente para inventarios y bases de datos. Ofrece sincronización en tiempo real, interfaz móvil optimizada y control de acceso, algo que las hojas de cálculo generales no pueden ofrecer eficientemente.',
    },
    {
      question: '¿Cómo funciona la sincronización multiplataforma?',
      answer: 'Utilizamos una base de datos en la nube de alto rendimiento. Cada cambio se guarda al instante y se notifica a todos los dispositivos conectados en milisegundos.',
    },
    {
      question: '¿Puedo exportar mis datos?',
      answer: 'Sí, en todos los planes puedes exportar tus datos en formatos comunes como CSV y JSON para copias de seguridad o integración con otros sistemas.',
    },
    {
      question: '¿Qué incluye el soporte prioritario del plan Empresa?',
      answer: 'El soporte prioritario garantiza un tiempo de respuesta de menos de 1 hora a través de un canal dedicado (chat o teléfono), además de un gestor de cuenta asignado.',
    },
  ];

  return (
    <section id="faq" className="section bg-white animate-on-scroll" role="region" aria-label="Preguntas Frecuentes">
      <div className="container" style={{ maxWidth: '896px' }}> {/* max-w-4xl */}
        <div className="text-center">
          <h2 className="text-3xl font-weight-extrabold" style={{ fontSize: '2rem' }}>
            Preguntas Frecuentes
          </h2>
          <p className="hero-subtitle" style={{ marginTop: 'var(--space-md)' }}>
            Resolvemos tus dudas más comunes sobre Lirsta.
          </p>
        </div>

        <div style={{ marginTop: '4rem', display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          {faqItems.map((item, index) => (
            <div key={index} className="card faq-card animate-on-scroll" style={{ transitionDelay: `${index * 0.1}s` }}>
              <h3 className="text-lg font-weight-bold text-gray-dark">{item.question}</h3>
              <p>{item.answer}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const ContactForm = () => {
  const [formData, setFormData] = useState({
      name: '',
      email: '',
      phone: '',
      businessName: '',
      skuCount: '',
      acceptTerms: false,
  });
  const [errors, setErrors] = useState({});
  const [submissionStatus, setSubmissionStatus] = useState('idle'); // idle, sending, success, error

  // Validación de todos los campos
  const validate = () => {
      let currentErrors = {};
      let isValid = true;
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      const phoneRegex = /^\d{7,15}$/; // Acepta entre 7 y 15 dígitos

      if (!formData.name.trim()) { currentErrors.name = 'El nombre es obligatorio.'; isValid = false; }
      if (!emailRegex.test(formData.email)) { currentErrors.email = 'Debe ser un formato de email válido.'; isValid = false; }
      if (formData.phone.trim() && !phoneRegex.test(formData.phone.trim())) { currentErrors.phone = 'El teléfono debe contener solo números (7-15 dígitos).'; isValid = false; }
      if (!formData.businessName.trim()) { currentErrors.businessName = 'El nombre del negocio es obligatorio.'; isValid = false; }
      
      const skuNum = parseInt(formData.skuCount);
      if (isNaN(skuNum) || skuNum < 1) {
           currentErrors.skuCount = 'El número de productos (SKUs) debe ser un número positivo (mínimo 1).'; isValid = false;
      }

      if (!formData.acceptTerms) { currentErrors.acceptTerms = 'Debe aceptar los términos y condiciones.'; isValid = false; }

      setErrors(currentErrors);
      return isValid;
  };

  const handleChange = (e) => {
      const { id, value, type, checked } = e.target;
      setFormData(prev => ({
          ...prev,
          [id]: type === 'checkbox' ? checked : value,
      }));
      
      // Limpiar error al cambiar si existe
      if (errors[id]) {
          setErrors(prev => ({ ...prev, [id]: undefined }));
      }
      if (submissionStatus === 'error') {
          setSubmissionStatus('idle'); // Permite reintentar
          setErrors({});
      }
  };

  const handleSubmit = (e) => {
      e.preventDefault();
      setSubmissionStatus('idle'); // Reset status before new attempt

      if (!validate()) {
          setSubmissionStatus('error');
          return;
      }

      setSubmissionStatus('sending');
      setErrors({}); // Clear errors on successful validation

      // Simulación de API call (2 segundos)
      setTimeout(() => {
          if (Math.random() > 0.1) { // 90% chance of success
              console.log('Formulario enviado con éxito:', formData);
              setSubmissionStatus('success');
              // Reset form data after successful submission
              setFormData({
                  name: '', email: '', phone: '', businessName: '', skuCount: '', acceptTerms: false,
              });
          } else {
              console.error('Simulación de error de servidor');
              setSubmissionStatus('error');
              // Set a general error message
              setErrors({ general: 'Ocurrió un error en el servidor. Por favor, intente de nuevo más tarde.' });
          }
      }, 2000);
  };

  const isSending = submissionStatus === 'sending';

  return (
    <section id="contacto" className="section bg-gray-light animate-on-scroll" role="region" aria-label="Formulario de Contacto e Inicio de Prueba">
      <div className="container">
        <div className="text-center">
          <h2 className="text-3xl font-weight-extrabold" style={{ fontSize: '2rem' }}>
            ¿Listo para Simplificar tu Inventario?
          </h2>
          <p className="hero-subtitle" style={{ marginTop: 'var(--space-md)' }}>
            Déjanos tus datos para empezar tu prueba gratuita o contarnos sobre tus necesidades.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="contact-form" noValidate>
          <div role="alert" aria-live="polite">
              {Object.keys(errors).length > 0 && errors.general && (
                  <div className="status-error" style={{ marginBottom: '1.5rem' }}>
                      {errors.general}
                  </div>
              )}
          </div>
          
          <div className="space-y-6">
            
            {/* Nombre */}
            <div className="form-group">
              {/* CORRECCIÓN: Se eliminó el </span> extra que cerraba prematuramente la etiqueta <label> */}
              <label htmlFor="name" className="form-label">Nombre Completo <span style={{ color: 'red' }}>*</span></label>
              <input
                type="text" id="name" required value={formData.name} onChange={handleChange}
                className={`form-input ${errors.name ? 'error' : ''}`} placeholder="Tu nombre"
                aria-invalid={!!errors.name} aria-describedby={errors.name ? 'error-name' : undefined}
              />
              {errors.name && <p id="error-name" className="form-error">{errors.name}</p>}
            </div>

            {/* Email */}
            <div className="form-group">
              <label htmlFor="email" className="form-label">Email de Contacto <span style={{ color: 'red' }}>*</span></label>
              <input
                type="email" id="email" required value={formData.email} onChange={handleChange}
                className={`form-input ${errors.email ? 'error' : ''}`} placeholder="tu.correo@ejemplo.com"
                aria-invalid={!!errors.email} aria-describedby={errors.email ? 'error-email' : undefined}
              />
              {errors.email && <p id="error-email" className="form-error">{errors.email}</p>}
            </div>

            {/* Teléfono */}
            <div className="form-group">
              <label htmlFor="phone" className="form-label">Teléfono (Solo números)</label>
              <input
                type="tel" id="phone" value={formData.phone} onChange={handleChange}
                className={`form-input ${errors.phone ? 'error' : ''}`} placeholder="Ej: 5551234567"
                aria-invalid={!!errors.phone} aria-describedby={errors.phone ? 'error-phone' : undefined}
              />
              {errors.phone && <p id="error-phone" className="form-error">{errors.phone}</p>}
            </div>

            {/* Nombre del Negocio */}
            <div className="form-group">
              <label htmlFor="businessName" className="form-label">Nombre del Negocio <span style={{ color: 'red' }}>*</span></label>
              <input
                type="text" id="businessName" required value={formData.businessName} onChange={handleChange}
                className={`form-input ${errors.businessName ? 'error' : ''}`} placeholder="Mi Empresa S.A."
                aria-invalid={!!errors.businessName} aria-describedby={errors.businessName ? 'error-businessName' : undefined}
              />
              {errors.businessName && <p id="error-businessName" className="form-error">{errors.businessName}</p>}
            </div>

            {/* Número de SKUs */}
            <div className="form-group">
              <label htmlFor="skuCount" className="form-label">Número de Productos (SKUs) <span style={{ color: 'red' }}>*</span></label>
              <input
                type="number" id="skuCount" required value={formData.skuCount} onChange={handleChange} min="1"
                className={`form-input ${errors.skuCount ? 'error' : ''}`} placeholder="Ej: 500"
                aria-invalid={!!errors.skuCount} aria-describedby={errors.skuCount ? 'error-skuCount' : undefined}
              />
              {errors.skuCount && <p id="error-skuCount" className="form-error">{errors.skuCount}</p>}
            </div>

            {/* Aceptación de Términos */}
            <div className="form-group">
              <div className="form-checkbox-group">
                <input
                  type="checkbox" id="acceptTerms" required checked={formData.acceptTerms} onChange={handleChange}
                  aria-invalid={!!errors.acceptTerms} aria-describedby={errors.acceptTerms ? 'error-acceptTerms' : undefined}
                />
                <label htmlFor="acceptTerms" className="form-label" style={{ marginBottom: 0, marginLeft: '0.25rem' }}>
                  Acepto los <a href="#footer" style={{ textDecoration: 'underline' }}>términos y condiciones</a> <span style={{ color: 'red' }}>*</span>
                </label>
              </div>
              {errors.acceptTerms && <p id="error-acceptTerms" className="form-error" style={{ marginLeft: '1.5rem' }}>{errors.acceptTerms}</p>}
            </div>

            <button
              type="submit"
              className="btn btn-primary w-full"
              disabled={isSending || submissionStatus === 'success'}
              aria-live="polite"
            >
              {isSending ? (
                <>
                  <div className="spinner"></div>
                  Enviando...
                </>
              ) : submissionStatus === 'success' ? (
                <>
                  <Check className="w-5 h-5 mr-2" />
                  ¡Enviado con Éxito!
                </>
              ) : (
                <>
                  Enviar y Comenzar Prueba
                  <Briefcase className="w-5 h-5 ml-2" />
                </>
              )}
            </button>
          </div>
          
          <div aria-live="polite">
            {submissionStatus === 'success' && (
                <div className="status-success" role="status">
                    ¡Gracias por tu interés! Hemos recibido tu solicitud y nos pondremos en contacto contigo pronto.
                </div>
            )}
            {submissionStatus === 'error' && Object.keys(errors).length === 0 && (
                <div className="status-error" role="status">
                    Ocurrió un error inesperado. Por favor, revisa tus datos e intenta de nuevo.
                </div>
            )}
          </div>

        </form>
      </div>
    </section>
  );
};

const Footer = () => (
  <footer className="footer" role="contentinfo">
    <div className="container footer-content">
      <div className="text-lg font-weight-bold">
        Lirsta
      </div>
      <p className="text-sm" style={{ color: 'var(--color-border)' }}>
        &copy; {new Date().getFullYear()} Lirsta. Todos los derechos reservados.
      </p>
      <div style={{ display: 'flex', gap: '1.5rem' }}>
        <a href="#planes" className="footer-link">Términos</a>
        <a href="#contacto" className="footer-link">Privacidad</a>
      </div>
    </div>
  </footer>
);


/* ----------------------------------------------------------------
   COMPONENTE PRINCIPAL (APP)
   ---------------------------------------------------------------- */

const App = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

  // Lógica de IntersectionObserver para animaciones
  useEffect(() => {
    // 1. ANIAMCIONES (IntersectionObserver)
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReducedMotion) return;

    const elements = document.querySelectorAll('.animate-on-scroll');
    if (elements.length === 0) return;

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, {
      root: null, 
      rootMargin: '0px 0px -10% 0px', 
      threshold: 0.1 
    });

    elements.forEach(element => {
      observer.observe(element);
    });

    // 2. SEO (Title, Meta, JSON-LD)
    document.title = "Lirsta — Inventarios sincronizados para tu negocio";

    let metaDescription = document.querySelector('meta[name="description"]');
    if (!metaDescription) {
        metaDescription = document.createElement('meta');
        metaDescription.name = 'description';
        document.head.appendChild(metaDescription);
    }
    metaDescription.content = "Lirsta es la forma más sencilla de crear, gestionar y compartir bases de datos e inventarios en tiempo real, desde cualquier plataforma.";

    const jsonLd = {
        "@context": "https://schema.org",
        "@graph": [
            {
                "@type": "Organization",
                "name": "Lirsta",
                "url": window.location.href,
                "description": "Aplicación para gestión de inventarios y bases de datos en la nube.",
            },
            {
                "@type": "Product",
                "name": "Lirsta Inventario Sincronizado",
                "description": "Software de gestión de inventario y bases de datos multiplataforma en tiempo real, con foco en accesibilidad y rapidez.",
                "offers": [
                    {
                        "@type": "Offer",
                        "name": "Plan Gratis",
                        "price": "0",
                        "priceCurrency": "EUR",
                        "availability": "https://schema.org/InStock"
                    },
                    {
                        "@type": "Offer",
                        "name": "Plan Pro",
                        "price": "15", // <-- Valor corregido, estaba en 25 en el query anterior, lo mantengo en 15.
                        "priceCurrency": "EUR",
                        "availability": "https://schema.org/InStock",
                        "description": "Sincronización multi-plataforma y colaboración para equipos pequeños."
                    },
                    {
                        "@type": "Offer",
                        "name": "Plan Empresa",
                        "price": "120", // <-- Valor corregido, estaba en 120 en el query anterior.
                        "priceCurrency": "EUR",
                        "availability": "https://schema.org/InStock",
                        "description": "Solución escalable con soporte prioritario y usuarios ilimitados."
                    }
                ]
            }
        ]
    };

    const script = document.createElement('script');
    script.type = 'application/ld+json';
    script.textContent = JSON.stringify(jsonLd);
    document.head.appendChild(script);
    
    // Cleanup function
    return () => {
        observer.disconnect();
        // Intentar remover el script JSON-LD al desmontar (si es posible)
        if (script.parentNode) {
            script.parentNode.removeChild(script);
        }
    };
  }, []);

  return (
    <div className="app-container" style={{ backgroundColor: 'var(--color-gray-light)', minHeight: '100vh' }}>
      <Navbar isMenuOpen={isMenuOpen} toggleMenu={toggleMenu} />
      
      <main id="main-content" role="main" tabIndex="-1">
        <Hero />
        <Steps />
        <Pricing />
        <Features />
        <Checklist />
        <FAQ />
        <DeploymentGuide />
        <ContactForm />
      </main>

      <Footer />
    </div>
  );
};

export default App;